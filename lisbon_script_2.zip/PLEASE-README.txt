Thank you for download the font. This font is for PERSONAL USE ONLY.
For any commercial use, 
you can download the full license here :  https://crmrkt.com/kj9ajR




VeroType Studio